package com.example.ar391064.wicruit;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by AR391064 on 11/10/2017.
 */

public class Login extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login1);

    }
}